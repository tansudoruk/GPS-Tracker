package com.brandonjenniges.javamailapidemo;


        import android.app.AlarmManager;
        import android.app.PendingIntent;
        import android.app.Service;
        import android.content.Context;
        import android.content.Intent;
        import android.os.IBinder;
        import android.os.SystemClock;
        import android.support.annotation.Nullable;
        import android.widget.Toast;

/**
 * Created by mercimek on 25.05.2017.
 */
public class OnBootReceiver  extends Service {



    private static final int PERIOD = 60000;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        AlarmManager mgr = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(OnBootReceiver.this, OnGPSReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(OnBootReceiver.this, 0, i, 0);

        mgr.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(), PERIOD, pi);
        return super.onStartCommand(intent,flags,startId);
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
