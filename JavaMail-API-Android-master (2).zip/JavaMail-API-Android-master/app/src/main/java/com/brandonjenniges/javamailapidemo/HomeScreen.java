package com.brandonjenniges.javamailapidemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.Manifest;
import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HomeScreen extends AppCompatActivity {
    Button button;
    static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static Random rnd = new Random();
    private static LocationManager mLocationmanager = null;
    Double _curLat = 0.0;
    Double _curLng = 0.0;
    Button btn;
    ProgressDialog pDialog;
    String url = "http://findmylocation.co.nf/add.php";
    String veri_string;
    PostClass post = new PostClass();
    static String deviceIMEI;
    static String temp;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        b = (Button)findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(HomeScreen.this,MainActivity.class);
                startActivity(i);
            }
        });


        btn=(Button)findViewById(R.id.btn);


        if(servisCalisiyormu()){//Servis Çalışıyor mu kontrol
            btn.setText("STOP");
            btn.setBackgroundColor(Color.RED);
        }else{
            btn.setText("START");
            btn.setBackgroundColor(Color.GREEN);
        }

        SetGPSLocation();

        TelephonyManager TelephonyMgr = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        deviceIMEI = TelephonyMgr.getDeviceId();


        SharedPreferences preferences = getPreferences(MODE_WORLD_WRITEABLE | MODE_WORLD_READABLE);
        SharedPreferences.Editor editor = preferences.edit();
        String _storedPass = preferences.getString("_pass", null);
        if (_storedPass == null) {
            temp = randomString(10);

            editor.putString("_pass", temp);
            editor.commit();
            //IMG vePASSWORDU php koduna gönderiyoruz ve mysqle kaydediyoruz.
            new Post().execute();
        } else {

            this.temp = temp;
            editor.putString("_pass", _storedPass);
            editor.commit();
        }


        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeScreen.this,MainActivity.class);
                startActivity(i);
            }
        });



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // TODO Auto-generated method stub
                Log.d("Servis Çalışıyor mu",""+servisCalisiyormu());
                if(servisCalisiyormu()){//Servis çalışıyorsa
                    Intent intent = new Intent(getApplicationContext(),OnBootReceiver.class);
                    stopService(intent);//servisi durdurur

                    btn.setText("START");
                    btn.setBackgroundColor(Color.GREEN);

                }else{//Servis çalışmıyorsa

                    Intent intent = new Intent(getApplicationContext(),OnBootReceiver.class);
                    startService(intent);//Servisi başlatır
                    btn.setText("STOP");

                    btn.setBackgroundColor(Color.RED);
                }



            }
        });

    }


    String randomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++)
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        return sb.toString();
    }

    public boolean servisCalisiyormu(){//Servis Çalışıyor mu kontrol eden fonksiyon

        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ( OnBootReceiver.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void SetGPSLocation() {
        mLocationmanager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location l = mLocationmanager
                .getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (l != null) {

            _curLat = l.getLatitude();
            _curLng = l.getLongitude();
            Log.i("lat", String.valueOf(_curLat));
            Log.i("lng", String.valueOf(_curLng));

        } else {
            Location l1 = mLocationmanager
                    .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            if (l1 != null) {
                _curLat = l1.getLatitude();
                _curLng = l1.getLongitude();
                Log.i("latnetwork", String.valueOf(_curLat));
                Log.i("lngnetwork", String.valueOf(_curLng));
            } else {
                _curLat = 0.0;
                _curLng = 0.0;
                Toast.makeText(HomeScreen.this, "NO GPS location found",
                        Toast.LENGTH_SHORT).show();
            }

        }

    }
    class Post extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() { // Post tan önce yapılacak işlemler. Yükleniyor yazısını(ProgressDialog) gösterdik.
            pDialog = new ProgressDialog(HomeScreen.this);
            pDialog.setMessage("Yükleniyor...");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(false); // ProgressDialog u iptal edilemez hale getirdik.
            pDialog.show();
        }

        protected Void doInBackground(Void... unused) { // Arka Planda yapılacaklar. Yani Post işlemi

            List<NameValuePair> params = new ArrayList<NameValuePair>(); //Post edilecek değişkenleri ayarliyoruz.
            //Bu değişkenler bu uygulamada hiçbir işe yaramıyor.Sadece göstermek amaçlı
            params.add(new BasicNameValuePair("isim",deviceIMEI));
            params.add(new BasicNameValuePair("mail",temp));

            veri_string = post.httpPost(url,"POST",params,20000); //PostClass daki httpPost metodunu çağırdık.Gelen string değerini aldık

            Log.d("HTTP POST CEVAP:",""+veri_string);// gelen veriyi log tuttuk

            return null;
        }

        protected void onPostExecute(Void unused) { //Posttan sonra
            pDialog.dismiss();  //ProgresDialog u kapatıyoruz.
        }
    }





}


