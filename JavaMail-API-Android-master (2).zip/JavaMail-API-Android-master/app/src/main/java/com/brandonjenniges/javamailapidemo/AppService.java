package com.brandonjenniges.javamailapidemo;


        import android.Manifest;
        import android.app.ActivityManager;
        import android.content.Context;
        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.location.Location;
        import android.location.LocationListener;
        import android.location.LocationManager;
        import android.os.Bundle;
        import android.support.v4.app.ActivityCompat;
        import android.telephony.TelephonyManager;
        import android.util.Log;
        import android.widget.Toast;

        import org.apache.http.HttpEntity;
        import org.apache.http.HttpResponse;
        import org.apache.http.client.ClientProtocolException;
        import org.apache.http.client.methods.HttpPost;
        import org.apache.http.client.params.ClientPNames;
        import org.apache.http.client.params.CookiePolicy;
        import org.apache.http.impl.client.DefaultHttpClient;
        import org.apache.http.protocol.HttpContext;

        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStream;
        import java.io.InputStreamReader;

/**
 * Created by mercimek on 25.05.2017.
 */
public class AppService extends WakefulIntentService {
    private LocationManager lm;
    private LocationListener locationListener;

    private static LocationManager mLocationmanager = null;
    Double _curLat;
    Double _curLng;


    public AppService() {
        super("AppService");
    }

    public boolean servisCalisiyormu(){//Servis Çalışıyor mu kontrol eden fonksiyon

        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ( OnBootReceiver.class.getName().equals(service.service.getClassName())) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onDestroy() {
        // Cancel the persistent notification.
        super.onDestroy();
    }



    @Override
    void doWakefulWork(Intent intent) {
        try {

            if (servisCalisiyormu()) {//Servis çalışıyorsa
                onDestroy();

            } else {//Servis çalışmıyorsa


                lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                locationListener = new MyLocationListener();

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
                        locationListener);

                TelephonyManager TelephonyMgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
                String deviceIMEI = TelephonyMgr.getDeviceId();

                SetGPSLocation();
                PostData(deviceIMEI, _curLat, _curLng);
                Log.e(".", "posted");
            }}catch(Exception e){

            Log.e(".", "Error");
        }
    }



    public String PostData(String devid, Double lattitude, Double longtitude) {
        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpContext localContext = new org.apache.http.protocol.BasicHttpContext();

        HttpResponse response = null;
        HttpPost httpPost = null;

        String url = "http://findmylocation.co.nf/addLocation.php?DeviceID="
                + devid
                + "&lattitude="
                + Double.toString(lattitude)
                + "&longtitude=" + Double.toString(longtitude);

        Log.d("url", url);

        httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY,
                CookiePolicy.RFC_2109);

        httpPost = new HttpPost(url);
        response = null;

        try {
            response = httpClient.execute(httpPost, localContext);

        } catch (ClientProtocolException e) {
            System.out.println("HTTPHelp : ClientProtocolException : " + e);
        } catch (IOException e) {
            System.out.println("HTTPHelp : IOException : " + e);
        }

        HttpEntity entity = response.getEntity();
        String result = "error";
        // A Simple JSON Response Read
        InputStream instream;
        try {
            instream = entity.getContent();

            result = convertStreamToString(instream);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
        return result;
    }

    private static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public void SetGPSLocation() {
        mLocationmanager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location l = mLocationmanager
                .getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (l != null) {
            _curLat = l.getLatitude();
            _curLng = l.getLongitude();
        } else {
            Location l1 = mLocationmanager
                    .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            if (l1 != null) {
                _curLat = l1.getLatitude();
                _curLng = l1.getLongitude();
            } else {
                _curLat = 0.0;
                _curLng = 0.0;
            }

        }

    }

    private class MyLocationListener implements LocationListener {
        @Override
        public void onLocationChanged(Location loc) {
            if (loc != null) {

                _curLat = loc.getLatitude();
                _curLng = loc.getLongitude();

            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            // TODO Auto-generated method stub
        }

        @Override
        public void onProviderEnabled(String provider) {
            // TODO Auto-generated method stub
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            // TODO Auto-generated method stub
        }
    }
}

